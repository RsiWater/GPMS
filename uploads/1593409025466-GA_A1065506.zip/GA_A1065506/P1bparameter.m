function x = P1bparameter(population)
    x = zeros(population,3);
    X = zeros(1,3);
    inRang = [0:1023];
    rang = rescale(inRang,-3,3); %�]�w��Ӫ�
    for i = 1:population
        while true
            x1 = int32(1023*rand());
            x2 = int32(1023*rand());
            x3 = int32(1023*rand());
            X1 = rang(x1+1);
            X2 = rang(x2+1);
            X3 = rang(x3+1);
            if ((X1+X2+X3>0) && (X1+X2+X3)<5) %�T�{ X1 + X2 +X3 �b�d��
                X(1:3)=[x1,x2,x3];
                P1z = midP1(X);
                if ~isnan(P1z) %�T�{�a�J�ȬO�_�]�b�d��
                    x(i,1:3)=[x1,x2,x3];
                    break;
                end
            end
        end
    end
end

