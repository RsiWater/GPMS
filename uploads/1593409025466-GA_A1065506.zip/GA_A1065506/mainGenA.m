%[x,val]=GenA(@midP1,3,[]);
[x,val]=GenA(@midP1b,3,@P1bparameter);
%[x,val]=GenA(@midP2,5,[]);
%[x,val]=GenA(@midP3,10,[]);
%[x,val]=GenA(@midP4,10,[]);