function [ y,x ] = midP1(X)
    inRang = [0:1023];
    rang = rescale(inRang,-3,3); %�]�w��Ӫ�
    for i = 1:3 % x�̷ӹ�Ӫ��ק�
        x(i)=rang(X(i)+1);
    end
    x1=x(1);
    x2=x(2);
    x3=x(3);
    tmp1 = x1.^2 + x2.^2;
    tmp4 = x1.^2 + x2.^2 + x3.^(2.5);
    tmp2 = tmp4.^(0.25);
    tmp3 = tmp1.^(0.1);
    angle = 50 .* tmp3;
    s = (sin(angle)).^2;
    y = tmp2 .* ((x3.^2) .* s);
    if ~(isreal(y))
        y = NaN;
    end
end