function[y,x]=midP2(X)
    inRang = [0:1023];
    rang = rescale(inRang,-32.768,32.768); %�]�w��Ӫ�
    for i = 1:5 % x�̷ӹ�Ӫ��ק�
        x(i)=rang(X(i)+1);
    end
    x1=x(1);
    x2=x(2);
    x3=x(3);
    x4=x(4);
    x5=x(5);
    fsum = x1.^2 + x2.^2 + x3.^2 + x4.^2 + x5.^2 ;
    ssum = cos(2 .* pi .* x1) + cos(2 .* pi .* x2)+ cos(2 .* pi .* x3)+cos(2 .* pi .* x4)+cos(2 .* pi .* x5);

    fsum=sqrt(fsum ./ 5);
    fsum=fsum .* (-(0.2));
    ssum=ssum ./ 5;
    y=(-20) .* exp(fsum)-exp(ssum)+20+exp(1);
        
     
end