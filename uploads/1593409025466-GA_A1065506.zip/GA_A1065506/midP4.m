function [Z,x]= midP4(X) % Z���N�J�� x���y��
    Z=0;
    inRang = [0:1023]; %�i�Ӫ��y�г��q�� 0~1023
    rang = rescale(inRang,0,pi); %�]�w��Ӫ�
    for i = 1:10 % x�̷ӹ�Ӫ��ק�
        x(i)=rang(X(i)+1);
    end
    
    for i = 1:10
        if i == 10
            y = x(i);
        elseif mod(i,2) == 1
            y = x(i) .* cos(pi/6)-x(i+1) .* sin(pi/6);
        elseif mod(i,2) == 0
            y = x(i) .* sin(pi/6)+x(i+1) .* cos(pi/6);
        end
        angleY1 = (y.^2)/pi;
        angleY2 = i.*(y.^2)/pi;
        tmp1 = (sin(angleY1)).^400;
        tmp2 = (sin(angleY2)).^400;
        a = sin(y) .* tmp1;
        b = sin(y) .* tmp2;
        Z = -(a + b)+Z;
    end
end